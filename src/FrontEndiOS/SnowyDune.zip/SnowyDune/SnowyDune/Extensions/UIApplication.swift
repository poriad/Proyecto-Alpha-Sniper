import UIKit

extension UIApplication {
    func setRootViewController(_ viewController: UIViewController) {
        UIApplication.shared.windows.filter {$0.isKeyWindow}.first?.rootViewController = viewController
    }
}
