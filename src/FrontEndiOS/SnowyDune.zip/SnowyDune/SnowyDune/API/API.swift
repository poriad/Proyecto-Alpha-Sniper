import Foundation

enum TripItemType {
    case resorts
    case hotels
    case classes
    case skiMaterials
    case carRentals
}

enum Endpoints {
    static let login = "/auth/login"
    static let resorts = "/api/stations/search/findByCountry?country=Espa%C3%B1a&page=0&size=20"
    static let hotels = "/api/hotel/search/listHotelByLocationStatusPageable?status=1&location=Sierra%20Nevada&page=0&size=20&sort=name,asc"
    static let classes = "/api/classes/search/listClassesByLocationStatusPageable?status=1&location=Sierra%20Nevada&page=0&size=8&sort=name,asc"
    static let skiMaterials = "/api/ski-material/search/listSkiMaterialByLocationStatusPageable?status=1&location=Sierra%20Nevada&page=0&size=20&sort=name,asc"
    static let carRentals = "/api/car-rental/search/listCarRentalByLocationStatusPageable?status=1&location=Sierra%20Nevada&page=0&size=20&sort=name,asc"
}

class API {
    static let shared = API()
    
    private let host = "http://192.168.1.134:8082"
    private var authorization: Authorization?
    
    private init() { }
    
    func login(username: String, password: String, completion: @escaping (Result<Authorization, Error>) -> Void) {
        guard let url = URL(string: host + Endpoints.login) else {
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = try? JSONEncoder().encode(UserCredentials(username: username, password: password))
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        requestData(with: request) { (result: Result<Authorization, Error>) in
            if case let .success(authorization) = result {
                self.authorization = authorization
            }
            
            completion(result)
        }
    }
    
    func getTripItems(of type: TripItemType, completion: @escaping (Result<[TripItem], Error>) -> Void) {
        guard let authorization = authorization, let url = URL(string: host + endpointForTripItems(of: type)) else {
            return
        }
        
        var request = URLRequest(url: url)
        request.addValue("\(authorization.bearer) \(authorization.token)", forHTTPHeaderField: "Authorization")
        requestData(with: request) { (result: Result<TripItems, Error>) in
            switch result {
            case let .success(tripItems):
                completion(.success(tripItems.items))
            case let .failure(error):
                completion(.failure(error))
            }
        }
    }
    
    private func requestData<T: Decodable>(with request: URLRequest, completion: @escaping (Result<T, Error>) -> Void) {
        URLSession.shared.dataTask(with: request) { data, response, error in
            guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.failure(NSError()))
                }
                return
            }
            
            if let data = data, let decodedResponse = try? JSONDecoder().decode(T.self, from: data) {
                DispatchQueue.main.async {
                    completion(.success(decodedResponse))
                }
            } else {
                completion(.failure(NSError()))
            }
        }.resume()
    }
    
    private func endpointForTripItems(of type: TripItemType) -> String {
        switch type {
        case .resorts:
            return Endpoints.resorts
        case .hotels:
            return Endpoints.hotels
        case .classes:
            return Endpoints.classes
        case .skiMaterials:
            return Endpoints.skiMaterials
        case .carRentals:
            return Endpoints.carRentals
        }
    }
}
