import Foundation

struct UserCredentials: Codable {
    var username: String
    var password: String
}
