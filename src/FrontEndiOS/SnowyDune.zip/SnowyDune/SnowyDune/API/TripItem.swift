import Foundation

enum ResponseKeys: String, CodingKey {
    case _embedded
}

struct TripItems: Decodable {
    enum CodingKeys: String, CodingKey {
        case station
        case hotel
        case classes
        case skiMaterial
        case carRental
    }
    
    let items: [TripItem]
    
    init(from decoder: Decoder) throws {
        let rootContainer = try decoder.container(keyedBy: ResponseKeys.self)
        let embeddedContainer = try rootContainer.nestedContainer(keyedBy: CodingKeys.self, forKey: ._embedded)
        
        if let stations = try? embeddedContainer.decode([TripItem].self, forKey: .station) {
            items = stations
        } else if let hotels = try? embeddedContainer.decode([TripItem].self, forKey: .hotel) {
            items = hotels
        } else if let classes = try? embeddedContainer.decode([TripItem].self, forKey: .classes) {
            items = classes
        } else if let skiMaterials = try? embeddedContainer.decode([TripItem].self, forKey: .skiMaterial) {
            items = skiMaterials
        } else {
            items = try embeddedContainer.decode([TripItem].self, forKey: .carRental)
        }
    }
}

struct TripItem: Codable {
    var name: String
    var location: String
    var country: String?
    var description: String
    var urlImages: String?
}
