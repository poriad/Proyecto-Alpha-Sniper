import Foundation

struct Authorization: Codable {
    var token: String
    var bearer: String
}
