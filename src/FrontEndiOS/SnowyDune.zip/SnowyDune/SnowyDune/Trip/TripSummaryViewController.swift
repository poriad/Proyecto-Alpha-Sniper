import UIKit

class TripSummaryViewController: UIViewController {
    
    @IBOutlet var resortNameLabel: UILabel!
    
    var trip: Trip?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Resumen viaje"
        
        resortNameLabel.text = trip?.resort?.name
    }
    
}
