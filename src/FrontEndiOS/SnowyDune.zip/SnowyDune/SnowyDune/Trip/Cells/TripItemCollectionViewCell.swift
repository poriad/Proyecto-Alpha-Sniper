import Kingfisher
import UIKit

class TripItemCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var imageView: UIImageView!
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var subtitleLabel: UILabel!
    
    var item: TripItem? {
        didSet {
            guard let item = item else {
                return
            }
            
            titleLabel.text = item.name
            subtitleLabel.text = item.location
            if let url = item.urlImages, let imageUrl = URL(string: url) {
                imageView.kf.setImage(with: imageUrl)
            }
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        imageView.kf.indicatorType = .activity
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        imageView.image = nil
        titleLabel.text = nil
        subtitleLabel.text = nil
    }

}
