import UIKit

class TripViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Inicio"
        setNavigationBarLogo()
        setNavigationBarLogoutButton()
    }
    
    private func setNavigationBarLogo() {
        let titleView = UIView()
        let logoImageView = UIImageView(image: UIImage(named: "Logo"))
        logoImageView.contentMode = .scaleAspectFit
        titleView.addSubview(logoImageView)
        
        logoImageView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            logoImageView.topAnchor.constraint(equalTo: titleView.topAnchor, constant: 5),
            logoImageView.bottomAnchor.constraint(equalTo: titleView.bottomAnchor, constant: -5),
            logoImageView.centerXAnchor.constraint(equalTo: titleView.centerXAnchor)
        ])
        
        navigationItem.titleView = titleView
    }
    
    private func setNavigationBarLogoutButton() {
        guard let navigationBarHeight = navigationController?.navigationBar.bounds.height else {
            return
        }
        
        let logoutButton = UIButton(type: .system)
        logoutButton.setImage(UIImage(named: "LogoutIcon"), for: .normal)
        logoutButton.imageEdgeInsets = UIEdgeInsets(top: 8, left: 8, bottom: 8, right: 8)
        logoutButton.addTarget(self, action: #selector(logoutButtonTapped), for: .touchUpInside)
        if let brandColor = UIColor(named: "BrandColor") {
            logoutButton.tintColor = brandColor
        }
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: logoutButton)
        
        logoutButton.widthAnchor.constraint(equalToConstant: navigationBarHeight).isActive = true
        logoutButton.heightAnchor.constraint(equalTo: logoutButton.widthAnchor).isActive = true
    }
    
    @objc func logoutButtonTapped() {
        let storyboard = UIStoryboard(name: "Login", bundle: nil)
        if let loginController = storyboard.instantiateInitialViewController() {
            UIApplication.shared.setRootViewController(loginController)
        }
    }
    
    @IBAction func createTripButtonTapped(_ sender: Any) {
        let tripStoryboard = UIStoryboard(name: "Trip", bundle: nil)
        guard let tripItemController = tripStoryboard.instantiateViewController(withIdentifier: "TripItemViewController") as? TripItemViewController else {
            return
        }
        tripItemController.trip = Trip()
        tripItemController.itemType = .resorts
        navigationController?.pushViewController(tripItemController, animated: true)
    }
    
}
