import UIKit

class TripItemViewController: UIViewController {
    
    @IBOutlet var itemsCollectionView: UICollectionView!
    
    var trip: Trip?
    var itemType: TripItemType? {
        didSet {
            updateTitle()
        }
    }
    
    private var items: [TripItem]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        itemsCollectionView.contentInset = UIEdgeInsets(top: 20, left: 20, bottom: 20, right: 20)
        registerCells()
        loadItems()
    }
    
    private func registerCells() {
        let nib = UINib(nibName: "TripItemCollectionViewCell", bundle: nil)
        itemsCollectionView.register(nib, forCellWithReuseIdentifier: "TripItemCollectionViewCell")
    }
    
    private func loadItems() {
        guard let itemType = itemType else {
            return
        }
        
        API.shared.getTripItems(of: itemType) { result in
            switch result {
            case let .success(items):
                self.items = items
                self.itemsCollectionView.reloadData()
                return
            case .failure(_):
                return
            }
        }
    }
    
    private func selectItem(_ item: TripItem) {
        addItemToTrip(item)
        
        let tripStoryboard = UIStoryboard(name: "Trip", bundle: nil)
        if itemType == TripItemType.carRentals {
            guard let tripSummaryController = tripStoryboard.instantiateViewController(withIdentifier: "TripSummaryViewController") as? TripSummaryViewController else {
                return
            }
            tripSummaryController.trip = trip
            navigationController?.pushViewController(tripSummaryController, animated: true)
        } else {
            guard let tripItemController = tripStoryboard.instantiateViewController(withIdentifier: "TripItemViewController") as? TripItemViewController else {
                return
            }
            tripItemController.trip = trip
            tripItemController.itemType = nextItemType()
            navigationController?.pushViewController(tripItemController, animated: true)
        }
    }
    
    private func addItemToTrip(_ item: TripItem) {
        switch itemType {
        case .resorts:
            trip?.resort = item
        case .hotels:
            trip?.hotel = item
        case .classes:
            trip?.classes = item
        case .skiMaterials:
            trip?.skiMaterial = item
        case .carRentals:
            trip?.carRental = item
        default:
            break
        }
    }
    
    private func updateTitle() {
        switch itemType {
        case .hotels:
            title = "Hotel"
        case .classes:
            title = "Clases"
        case .skiMaterials:
            title = "Material de ski"
        case .carRentals:
            title = "Alquiler de vehículos"
        default:
            title = "Estación"
        }
    }
    
    private func nextItemType() -> TripItemType {
        switch itemType {
        case .resorts:
            return .hotels
        case .hotels:
            return .classes
        case .classes:
            return .skiMaterials
        case .skiMaterials:
            return .carRentals
        default:
            return .resorts
        }
    }
    
}

extension TripItemViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return items?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "TripItemCollectionViewCell", for: indexPath) as? TripItemCollectionViewCell else {
            return UICollectionViewCell()
        }
        
        cell.item = items?[indexPath.item]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        var width = collectionView.bounds.width - collectionView.contentInset.left - collectionView.contentInset.right
        if UIDevice.current.userInterfaceIdiom == .pad, let flowLayout = collectionViewLayout as? UICollectionViewFlowLayout {
            width = (collectionView.bounds.width - collectionView.contentInset.left - collectionView.contentInset.right - flowLayout.minimumInteritemSpacing) / 2
        }
        let height = width * (9.0 / 16.0) + 100
        return CGSize(width: width, height: height)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let item = items?[indexPath.item] else {
            return
        }
        
        selectItem(item)
    }
    
}
