import Foundation

struct Trip {
    var resort: TripItem?
    var hotel: TripItem?
    var classes: TripItem?
    var skiMaterial: TripItem?
    var carRental: TripItem?
}
