import UIKit

class LoginViewController: UIViewController {
    
    @IBOutlet var loginStackView: UIStackView!
    
    @IBOutlet var userView: UIView!
    @IBOutlet var userTextField: UITextField!
    
    @IBOutlet var passwordView: UIView!
    @IBOutlet var passwordTextField: UITextField!
    
    @IBOutlet var loginButtonView: UIView!
    @IBOutlet var loginButton: UIButton!
    @IBOutlet var loginActivityIndicator: UIActivityIndicatorView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loginStackView.setCustomSpacing(40, after: passwordView)
        
        #if DEBUG
        userTextField.text = "admin"
        passwordTextField.text = "admin1"
        #endif
    }
    
    @IBAction func dismissKeyboardTapped(_ sender: Any) {
        view.endEditing(true)
    }
    
    @IBAction func loginButtonTapped(_ sender: Any) {
        login()
    }
    
    private func login() {
        guard let user = userTextField.text, let password = passwordTextField.text else {
            return
        }
        
        view.endEditing(true)
        loginButton.isHidden = true
        loginActivityIndicator.startAnimating()
        
        API.shared.login(username: user, password: password) { result in
            switch result {
            case .success(_):
                let tripStoryboard = UIStoryboard(name: "Trip", bundle: nil)
                if let tripController = tripStoryboard.instantiateInitialViewController()  {
                    UIApplication.shared.setRootViewController(tripController)
                }
            case .failure(_):
                break
            }
            
            self.loginButton.isHidden = false
            self.loginActivityIndicator.stopAnimating()
        }
    }
    
}

extension LoginViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == userTextField {
            passwordTextField.becomeFirstResponder()
        } else {
            login()
        }
        return true
    }
}
